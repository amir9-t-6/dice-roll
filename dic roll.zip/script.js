'use strict';

// # is for id's and . is for classes

//Selecting elements. Storing them into variables as we will use those selected elements multiple times throughout the applications.instead of selecting them over and over
const player0El = document.querySelector('.player--0');
const player1El = document.querySelector('.player--1');
const score0El = document.querySelector('#score--0');
const score1El = document.getElementById('score--1');
const currentEl0 = document.getElementById('current--0');
const currentEl1 = document.getElementById('current--1');

const tallyPlayer1 = document.getElementById('tallyScore-1');
const tallyPlayer2 = document.getElementById('tallyScore-2');

const modal = document.querySelector('.modal');
const closebtn = document.querySelector('.close-modal');

const diceEl = document.querySelector('.dice');
const btnNew = document.querySelector('.btn--new');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const btnTally = document.querySelector('.btn--tally');

let totalScore = [0, 0];
let scores, currentScore, activePlayer, playing;

const init = function () {
  //setting the scores to 0. Starting codition

  // setting the scores to 0. We cannot put the following in the function as the it would be set to zero everytime we click the button. That's why it is outside
  // totalScore = [0, 0];
  scores = [0, 0];
  currentScore = 0;
  activePlayer = 0;
  playing = true;

  score0El.textContent = 0;
  score1El.textContent = 0;
  currentEl0.textContent = 0;
  currentEl1.textContent = 0;
  //Hides the dice. Class list selects the element from the css!!
  diceEl.classList.add('hidden');
  player0El.classList.remove('player--winner');
  player1El.classList.remove('player--winner');
  player0El.classList.add('player--active');
  player1El.classList.remove('player--active');
};

init();

const switchPlayer = function () {
  document.getElementById(`current--${activePlayer}`).textContent = 0;
  //if the active player is 0, then we want the new active player to be 1 and else it should be zero

  activePlayer = activePlayer === 0 ? 1 : 0;
  currentScore = 0;
  player0El.classList.toggle('player--active'); //toggle will add the class if it is not there. it will remove the class if it is there and if it is not it will add it
  player1El.classList.toggle('player--active');
};

//Rolling dice functionality
//private function is used as the function wont be used in the future.
btnRoll.addEventListener('click', function () {
  // playing is a boolen varible and thats why we dont write condition (== true), playing is already a boolen set before ^
  if (playing) {
    // 1. Generateing a random dice roll
    const dice = Math.trunc(Math.random() * 6) + 1;
    // 2. display the dice
    diceEl.classList.remove('hidden'); //removing the hidden class that is already hidden before game starts
    diceEl.src = `dice-${dice}.png`; // we use the beginning of the file name "dice-" and then the dice number will come from the ${dice}.

    // 3. check for a rolled 1: if true, switch to next player
    if (dice !== 1) {
      // Add dice to current score
      currentScore += dice;
      document.getElementById(
        `current--${activePlayer}`
      ).textContent = currentScore;
    } else {
      //Switch to the next player
      switchPlayer();
    }
  }
});

//Hold button
btnHold.addEventListener('click', function () {
  if (playing) {
    //1. Add current score to active player's score
    scores[activePlayer] += currentScore;

    document.getElementById(`score--${activePlayer}`).textContent =
      scores[activePlayer];
    //2. Check sore player's score is >=100
    if (scores[activePlayer] >= 10) {
      playing = false;
      diceEl.classList.add('hidden');
      // Finish the game
      document
        .querySelector(`.player--${activePlayer}`)
        .classList.add('player--winner');
      document
        .querySelector(`.player--${activePlayer}`)
        .classList.remove('player--active');
      totalScore[activePlayer]++;
      console.log(`player ${activePlayer + 1} has won`, totalScore);

      tallyPlayer1.innerHTML = totalScore[0];
      tallyPlayer2.innerHTML = totalScore[1];
    } else {
      // Switch to the next player
      switchPlayer();
    }
  }
});
// btnTally.addEventListener('click', function(){
//   if(scores[activePlayer] >= 10 && activePlayer == 0){
//     totalScore[activePlayer]++;

//   //   console.log("Player 1 Wins")

//   //   console.log(totalScore[0]);
//   // } else{
//   //   console.log("Player 2 Wins")
//   }

//   });
btnNew.addEventListener('click', init);

// listen for open
btnTally.addEventListener('click', openModal);
// listen for close click
closebtn.addEventListener('click', closeModal);
// Outside click
window.addEventListener('click', outSideClick);
//opens the modal. Take the display from the css (which is hidden on css), and then display block to show the modal....
function openModal() {
  modal.style.display = 'block';
}
// function to close modal.
function closeModal() {
  modal.style.display = 'none';
}
// Function to close window if clicked outside
function outSideClick(f) {
  if (f.target == modal) {
    modal.style.display = 'none';
  }
}
// document.getElementById().tex;

// we should not store any data in the dom
